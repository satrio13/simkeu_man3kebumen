<?php
$excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
$excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, '');