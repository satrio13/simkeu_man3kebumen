<div class="col-md-12 bg-white border border-info mb-2">
    <div class="row">
      	<div class="col-md-12 text-center p-2">
        	BELUM ADA TAGIHAN
      	</div>
    </div>
 </div>